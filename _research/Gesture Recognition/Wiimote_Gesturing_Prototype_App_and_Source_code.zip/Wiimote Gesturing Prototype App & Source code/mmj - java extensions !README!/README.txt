These two files need to be put inside ~/Library/Java/Extensions/ 
in order for Java to gain access to all MIDI devices installed
on your system.

