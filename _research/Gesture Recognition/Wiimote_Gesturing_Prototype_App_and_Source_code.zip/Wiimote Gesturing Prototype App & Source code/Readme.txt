This application was made for Mac OS X and was not tested on any PC's yet
due to lack of a PC with Bluetooth.

It is verified working on several Macbook Pro's and iMacs.

In order for the application to see all of the MIDI Out devices, additional
Java extensions need to be put in place. They are in the folder called "mmj".


The .jar program can be run from the Terminal like this:

"Java -jar /Users/xxxxxx/Wiimote_Gesturing_Prototype_02-09-09.jar"

If you have Mac OS X 10.6 Snow Leopard installed, the 64-bit version of the Java virtual machine may have been installed and you need to run the application with an extra argument "-d32" to let it run in 32-bit mode. This is necessary for the BlueCove library to work.

Then it becomes something like this:

"Java -jar -d32 /Users/xxxxxx/Wiimote_Gesturing_Prototype_02-09-09.jar"

Connect your wiimote right after executing this command by pressing 
buttons 1 & 2 at the same time. When the connection is established
(this may take a while) the graphical user interface will come up.


Have Fun,

Wout Standaert
http://www.blobkat.com
http://www.blobkat.com/blog



